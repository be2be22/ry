"""Aurora service layer package."""
