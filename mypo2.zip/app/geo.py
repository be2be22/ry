"""Offline IP-to-country lookup using a local MMDB database (geoip2)."""
from __future__ import annotations

import ipaddress
import os

_geo_reader = None
_loaded = False

_COUNTRY_FLAGS = {
    "AF": "🇦🇫", "AL": "🇩🇿", "DZ": "🇩🇿", "AD": "🇦🇩", "AO": "🇦🇴", "AR": "🇦🇷",
    "AM": "🇦🇲", "AU": "🇦🇺", "AT": "🇦🇹", "AZ": "🇦🇿", "BS": "🇧🇸", "BH": "🇧🇭",
    "BD": "🇧🇩", "BB": "🇧🇧", "BY": "🇧🇾", "BE": "🇧🇪", "BZ": "🇧🇿", "BJ": "🇧🇯",
    "BT": "🇧🇹", "BO": "🇧🇴", "BA": "🇧🇦", "BW": "🇧🇼", "BR": "🇧🇷", "BN": "🇧🇳",
    "BG": "🇧🇬", "BF": "🇧🇫", "BI": "🇧🇮", "KH": "🇰🇭", "CM": "🇨🇲", "CA": "🇨🇦",
    "CF": "🇨🇫", "TD": "🇹🇩", "CL": "🇨🇱", "CN": "🇨🇳", "CO": "🇨🇴", "KM": "🇰🇲",
    "CG": "🇨🇬", "CD": "🇨🇩", "CR": "🇨🇷", "HR": "🇭🇷", "CU": "🇨🇺", "CY": "🇨🇾",
    "CZ": "🇨🇿", "DK": "🇩🇰", "DJ": "🇩🇯", "DO": "🇩🇴", "EC": "🇪🇨", "EG": "🇪🇬",
    "SV": "🇸🇻", "GQ": "🇬🇶", "ER": "🇪🇷", "EE": "🇪🇪", "ET": "🇪🇹", "FJ": "🇫🇯",
    "FI": "🇫🇮", "FR": "🇫🇷", "GA": "🇬🇦", "GM": "🇬🇲", "GE": "🇬🇪", "DE": "🇩🇪",
    "GH": "🇬🇭", "GR": "🇬🇷", "GT": "🇬🇹", "GN": "🇬🇳", "GW": "🇬🇼", "GY": "🇬🇾",
    "HT": "🇭🇹", "HN": "🇭🇳", "HK": "🇭🇰", "HU": "🇭🇺", "IS": "🇮🇸", "IN": "🇮🇳",
    "ID": "🇮🇩", "IR": "🇮🇷", "IQ": "🇮🇶", "IE": "🇮🇪", "IL": "🇮🇱", "IT": "🇮🇹",
    "JM": "🇯🇲", "JP": "🇯🇵", "JO": "🇯🇴", "KZ": "🇰🇿", "KE": "🇰🇪", "KI": "🇰🇮",
    "KP": "🇰🇵", "KR": "🇰🇷", "KW": "🇰🇼", "KG": "🇰🇬", "LA": "🇱🇦", "LV": "🇱🇻",
    "LB": "🇱🇧", "LS": "🇱🇸", "LR": "🇱🇷", "LY": "🇱🇾", "LI": "🇱🇮", "LT": "🇱🇹",
    "LU": "🇱🇺", "MO": "🇲🇴", "MK": "🇲🇰", "MG": "🇲🇬", "MW": "🇲🇼", "MY": "🇲🇾",
    "MV": "🇲🇻", "ML": "🇲🇱", "MT": "🇲🇹", "MH": "🇲🇭", "MR": "🇲🇷", "MU": "🇲🇺",
    "MX": "🇲🇽", "FM": "🇫🇲", "MD": "🇲🇩", "MC": "🇲🇨", "MN": "🇲🇳", "ME": "🇲🇪",
    "MA": "🇲🇦", "MZ": "🇲🇿", "MM": "🇲🇲", "NA": "🇳🇦", "NR": "🇳🇷", "NP": "🇳🇵",
    "NL": "🇳🇱", "NZ": "🇳🇿", "NI": "🇳🇮", "NE": "🇳🇪", "NG": "🇳🇬", "NO": "🇳🇴",
    "OM": "🇴🇲", "PK": "🇵🇰", "PW": "🇵🇼", "PA": "🇵🇦", "PG": "🇵🇬", "PY": "🇵🇾",
    "PE": "🇵🇪", "PH": "🇵🇭", "PL": "🇵🇱", "PT": "🇵🇹", "QA": "🇶🇦", "RO": "🇷🇴",
    "RU": "🇷🇺", "RW": "🇷🇼", "WS": "🇼🇸", "SM": "🇸🇲", "SA": "🇸🇦", "SN": "🇸🇳",
    "RS": "🇷🇸", "SC": "🇸🇨", "SL": "🇸🇱", "SG": "🇸🇬", "SK": "🇸🇰", "SI": "🇸🇮",
    "SB": "🇸🇧", "SO": "🇸🇴", "ZA": "🇿🇦", "SS": "🇸🇸", "ES": "🇪🇸", "LK": "🇱🇰",
    "SD": "🇸🇩", "SR": "🇸🇷", "SE": "🇸🇪", "CH": "🇨🇭", "SY": "🇸🇾", "TW": "🇹🇼",
    "TJ": "🇹🇯", "TZ": "🇹🇿", "TH": "🇹🇭", "TL": "🇹🇱", "TG": "🇹🇬", "TO": "🇹🇴",
    "TT": "🇹🇹", "TN": "🇹🇳", "TR": "🇹🇷", "TM": "🇹🇲", "TV": "🇹🇻", "UG": "🇺🇬",
    "UA": "🇺🇦", "AE": "🇦🇪", "GB": "🇬🇧", "US": "🇺🇸", "UY": "🇺🇾", "UZ": "🇺🇿",
    "VU": "🇻🇺", "VE": "🇻🇪", "VN": "🇻🇳", "YE": "🇾🇪", "ZM": "🇿🇲", "ZW": "🇿🇼",
}


def _ensure_reader() -> None:
    global _geo_reader, _loaded
    if _loaded:
        return
    _loaded = True
    db_path = os.environ.get("GEOIP_DB_PATH", "/app/data/dbip-country-lite.mmdb")
    if not os.path.exists(db_path):
        return
    try:
        import geoip2.database
        _geo_reader = geoip2.database.Reader(db_path)
    except Exception:
        _geo_reader = None


def lookup_country(ip: str) -> tuple[str, str]:
    """Return (country_name, flag_emoji) for a public IP.

    Returns ("", "") if lookup fails or IP is private/reserved.
    """
    try:
        addr = ipaddress.ip_address(ip)
        if addr.is_private or addr.is_reserved or addr.is_loopback:
            return ("", "")
    except ValueError:
        return ("", "")

    _ensure_reader()
    if _geo_reader is None:
        return ("", "")
    try:
        resp = _geo_reader.country(ip)
        code = resp.country.iso_code or ""
        name = resp.country.name or ""
        flag = _COUNTRY_FLAGS.get(code, "")
        return (name, flag)
    except Exception:
        return ("", "")
